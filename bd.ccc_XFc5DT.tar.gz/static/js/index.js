    //update
var bob_h5 = "https://www.tquq1pt1.com:9969/entry/register?agent_code=6342892";//bob-h5
var bob_pc = "https://www.zencm9p6.com:9969/register?agent_code=6342892";//bob-pc
var boyu_pc = "https://www.zencm9p6.com:9970/register?agent_code=6342892";//bob-pc
var boyu_h5 = "https://www.tquq1pt1.com:9970/entry/register?agent_code=6342892";//bob-h5
var app_pc = "https://www.juzwpj.com:9999/?agent_code=6342892";//app_pc
var app_h5 = "https://www.juzwpj.com:9999/?agent_code=6342892";//app_h5
var boyu_baijiale = "https://www.boyu1304.com:30111/entry/register/?i_code=9348134";//博鱼-h5
var boyu_baijiale = "https://www.boyu1254.com:30473/register/?i_code=9348134";//博鱼-pc





